<?php

namespace App\Classes\Constants\Action;

class Points
{
    public const VALUES = [
        Name::PLANT => 15,
        Name::TO_WATER => 15,
        Name::CLEANING => 15,
        Name::FERTILIZER => 20,
        Name::GRIP => 15,
        Name::GAMES => 15
    ];
}
